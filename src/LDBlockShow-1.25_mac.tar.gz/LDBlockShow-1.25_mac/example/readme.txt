The examples here are all using [RR], if you need to use [D'],
use parameters  [-SeleVar 2]

1   Example1:  Quick outPut the  LDHeatMap 

2   Example2:  Output LDHeatMap combined with GWAS statistics

3   Example3:  Output LDHeatMap combined with GWAS statistics and genomic annotation
